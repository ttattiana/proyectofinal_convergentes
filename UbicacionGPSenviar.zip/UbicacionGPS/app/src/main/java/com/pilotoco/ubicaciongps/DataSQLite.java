package com.pilotoco.ubicaciongps;

import androidx.annotation.Nullable;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;


public class DataSQLite extends SQLiteOpenHelper{

    private static final String DB_NAME = "baseDatos.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME= "reporte_table";
    private static final String COL_1 = "ID";
    private static final String COL_2 = "USUARIO";
    private static final String COL_3 = "FECHA";
    private static final String COL_4  = "DESCRIPCION";
    private static final String COL_5 = "LATITUD";
    private static final String COL_6 = "LONGITUD";
    private static final String COL_7 = "PAIS";
    private static final String COL_8 = "CIUDAD";
    private static final String COL_9 = "DIRECCION";
    private static final String COL_10= "LOCALIDAD";
    private static final String COL_11= "KILOMETROS";
    private static final String COL_12= "METROS";


    public DataSQLite(@Nullable Context context) {
        super(context,DB_NAME, null, DB_VERSION );

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table reporte_table(ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "USUARIO,FECHA,DESCRIPCION,LATITUD,LONGITUD,PAIS,CIUDAD,DIRECCION," +
                "LOCALIDAD,KILOMETROS,METROS)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS"+ db);
        onCreate(db);

    }
    public void initData(){
        SQLiteDatabase db= this.getWritableDatabase();
        onUpgrade(db,1,1);
    }

    public Cursor getAllData(){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor result=db.rawQuery("select * from reporte_table",null);
        return result;
    }

    public Cursor getData(int id){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor rest=db.rawQuery("select * from reporte_table where id="+id+"",null);
        return rest;
    }

    //Consultar por usuario

    public Cursor getUsuario(String usuarioDB) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] selectionArgs = { usuarioDB };
        Cursor resp = db.rawQuery("SELECT * FROM reporte_table WHERE usuario=?", selectionArgs);
        return resp;
    }


    //insertar datos
    public boolean insertData( String usuario, String fecha, String descripcion, String  latitud,
                               String longitud, String pais, String ciudad, String direccion,
                               String localidad, String kilometros, String metros){
        SQLiteDatabase db= this.getWritableDatabase();  //instancia BD
        ContentValues contentValues= new ContentValues();
        contentValues.put(COL_2, usuario);
        contentValues.put(COL_3, fecha);
        contentValues.put(COL_4, descripcion);
        contentValues.put(COL_5,latitud);
        contentValues.put(COL_6, longitud);
        contentValues.put(COL_7, pais);
        contentValues.put(COL_8, ciudad);
        contentValues.put(COL_9, direccion);
        contentValues.put(COL_10,localidad);
        contentValues.put(COL_11,kilometros);
        contentValues.put(COL_12,metros);

        long resultado = db.insert(TABLE_NAME, null,contentValues);
        if (resultado == -1){
            return false;
        }
        return true;
    }

    //Insertar nuevo resporte mismo usuario
    public boolean insertarNuevoReporte(String usuario, String fecha, String descripcion, String  latitud,
                                   String longitud, String pais, String ciudad, String direccion,
                                   String localidad, String kilometros, String metros) {

            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues contentValues = new ContentValues();
            contentValues.put(COL_2, usuario);
            contentValues.put(COL_3, fecha);
            contentValues.put(COL_4, descripcion);
            contentValues.put(COL_5, latitud);
            contentValues.put(COL_6, longitud);
            contentValues.put(COL_7, pais);
            contentValues.put(COL_8, ciudad);
            contentValues.put(COL_9, direccion);
            contentValues.put(COL_10, localidad);
            contentValues.put(COL_11, kilometros);
            contentValues.put(COL_12, metros);

            long resultado = db.insert(TABLE_NAME, null, contentValues);
            if (resultado == -1) {
                return false;
            }

        return true;
    }

}

