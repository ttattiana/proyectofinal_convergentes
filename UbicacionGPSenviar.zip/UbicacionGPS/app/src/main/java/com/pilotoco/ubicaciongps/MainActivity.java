package com.pilotoco.ubicaciongps;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    DataSQLite myDB;
    EditText usuario, fecha, descripcion, Id, UsuarioBD;
    Button guardar,btnVerDatos, btLocation, btnInsertar, btnHistorial, btnInforme;
    TextView textView1,textView2, textView3,textView4,textView5,textView6,location_view,distancia,distanciaMetros;
    private FusedLocationProviderClient fusedLocationProviderClient;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Odometer
        mostrarDistancia();
        distanciaMetros();
        distancia = findViewById(R.id.distancia);
        distanciaMetros = findViewById(R.id.distanciaMetros);
        btnInforme = findViewById(R.id.btnInforme);
        viewInforme();

        //Formulario
        myDB = new DataSQLite(this);
        usuario = findViewById(R.id.editTextUsuario);
        fecha = findViewById(R.id.editTextFecha);
        descripcion = findViewById(R.id.editTextDescripcion);
        guardar = findViewById(R.id.btnGuardar);
        btnVerDatos = findViewById(R.id.btnVerDatos);
        btnHistorial = findViewById(R.id.btnHistorial);
        Id = findViewById(R.id.editTextId);
        UsuarioBD = findViewById(R.id.editTextUsuario);
        AddData();
        viewAll();
        viewData();
        //viewDataUsuario();

        // GPS
        btLocation = findViewById(R.id.bt_location);
        textView1 = findViewById(R.id.text_view1);
        textView2 = findViewById(R.id.text_view2);
        textView3 = findViewById(R.id.text_view3);
        textView4 = findViewById(R.id.text_view4);
        textView5 = findViewById(R.id.text_view5);
        textView6 = findViewById(R.id.text_view6);
        location_view = findViewById(R.id.location_view);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        btLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check permiso
                location_view.setText("Chek permission");
                if (ActivityCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                    location_view.setText("When permission granted");
                    getLocation();
                }else {
                    location_view.setText("When permission denied");
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
                }
            }
        });


    }

    public void getLocation(){
        if (ActivityCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
            fusedLocationProviderClient.getLastLocation().addOnCompleteListener(
                    new OnCompleteListener<Location>() {
                        @Override
                        public void onComplete(@NonNull Task<Location> task) {
                            Location location = task.getResult();
                            if (location !=null){
                                //inicializar Geocoder
                                Geocoder geocoder = new Geocoder(MainActivity.this,
                                        Locale.getDefault());

                                //inicializar litas de direcciones
                                try {
                                    List<Address> addresses = geocoder.getFromLocation(
                                            location.getLatitude(), location.getLongitude(),1
                                    );
                                    //Set latitud on TextView
                                    textView1.setText("Latitud:"+(double)addresses.get(0).getLatitude());
                                    //set longitud
                                    textView2.setText("Longitud:"+(double)addresses.get(0).getLatitude());
                                    //set pais name
                                    textView3.setText(addresses.get(0).getCountryName());
                                    //set ciudad on TextView
                                    textView4.setText(addresses.get(0).getLocality());
                                    //set direccion on TextView
                                    textView5.setText(addresses.get(0).getAddressLine(0));
                                    //set localidad on TextView
                                    textView6.setText("Localidad:"+addresses.get(0).getSubLocality());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }else {
                                if (ActivityCompat.checkSelfPermission(MainActivity.this,
                                        Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){
                                    getLocation();

                                }
                            }
                        }
                    }
            );
        }
    }

    ///Base de datos. Formulario
    public void AddData(){
        guardar.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick (View view) {
                        boolean insertar= myDB.insertData(usuario.getText().toString(), fecha.getText().toString(), descripcion.getText().toString(),
                                textView1.getText().toString(), textView2.getText().toString(), textView3.getText().toString(), textView4.getText().toString(),
                                textView5.getText().toString(), textView6.getText().toString(), distancia.getText().toString(), distanciaMetros.getText().toString());

                        if (insertar==true){
                            Toast.makeText(MainActivity.this, "Datos insertados", Toast.LENGTH_LONG).show();
                        }else
                            Toast.makeText(MainActivity.this, "No se insertaron los datos", Toast.LENGTH_LONG).show();

                    }
                }
        );

    }

    public void viewAll(){
        btnVerDatos.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDB.getAllData();
                        if (res.getCount()==0){
                            showMessage("Error", "No se encontro");
                            return;
                        }else {
                            StringBuffer buffer= new StringBuffer();
                            while (res.moveToNext()){
                                buffer.append("Id"+res.getString(0)+ "\n");
                                buffer.append("Usuario:"+res.getString(1)+ "\n");
                                buffer.append("Fecha:"+res.getString(2)+ "\n");
                                buffer.append("Descripcion:"+res.getString(3)+ "\n");
                                buffer.append(""+res.getString(4)+ "\n"); //Latitud
                                buffer.append(""+res.getString(5)+ "\n"); //Longitud
                                buffer.append("Pais:"+res.getString(6)+ "\n");
                                buffer.append("Ciudad:"+res.getString(7)+ "\n");
                                buffer.append("Direccion:"+res.getString(8)+ "\n");
                                buffer.append(""+res.getString(9)+ "\n"); //Localidad

                            }
                            showMessage("Datos",buffer.toString());
                        }
                    }
                }
        );
    }

    //Historial por ID
    public void viewData (){
        btnHistorial.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int id = Integer.parseInt(Id.getText().toString());
                        Cursor rest = myDB.getData(id);
                        if (rest.getCount() == 0) {
                            showMessage("Error", "No se encontro");
                            return;

                        } else {
                            StringBuffer buffer = new StringBuffer();
                            while (rest.moveToNext()) {
                                buffer.append("Id:" + rest.getString(0) + "\n");
                                buffer.append("Usuario:"+rest.getString(1)+ "\n");
                                buffer.append("Ciudad:"+rest.getString(7)+ "\n");
                                buffer.append("Direccion:"+rest.getString(8)+ "\n");
                                buffer.append(""+rest.getString(9)+ "\n"); //Localidad

                            }
                            showMessage("Historial",buffer.toString());
                        }

                    }
                }
        );

    }


    //Reporte area afectada
    public void viewInforme (){
        btnInforme.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int id = Integer.parseInt(Id.getText().toString());
                        Cursor rest = myDB.getData(id);
                        if (rest.getCount() == 0) {
                            showMessage("Error", "No se encontro");
                            return;

                        } else {
                            StringBuffer buffer = new StringBuffer();
                            while (rest.moveToNext()) {
                                buffer.append("Id:" + rest.getString(0) + "\n");
                                buffer.append("Usuario:"+rest.getString(1)+ "\n");
                                buffer.append("Ubicacion actual:"+rest.getString(8)+ "\n");
                                buffer.append(""+rest.getString(9)+ "\n"); //Localidad
                                buffer.append("Kilometros:"+rest.getString(10)+"\n");
                                buffer.append("Metros:"+rest.getString(11)+"\n");


                            }
                            showMessage("Informe",buffer.toString());
                        }

                    }
                }
        );

    }

    public void showMessage (String tittle, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(tittle);
        builder.setMessage(message);
        builder.show();

    }

    //Ruta muestra recorrido entre origen y destino
    public void onSendMaps(View view){
        Uri.Builder buider= new Uri.Builder();
        buider.scheme("https")
                .authority("www.google.com")
                .appendPath("maps")
                .appendPath("dir")
                .appendPath("dir")
                .appendQueryParameter("api","1")
                .appendQueryParameter("origin",4.0323397+","+-74.9653500)
                .appendQueryParameter("destination",4.632339710+","+-74.065350);
        String url= buider.build().toString();
        Log.d("Directions",url);
        Intent intent= new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
  //muestra coordenadas en latitud y longitud
    public void onSendMaps1(View view){
        Uri gmmIntentUri = Uri.parse("geo:37.7749,-122.4194");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW,gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        Log.d("Directions",gmmIntentUri.toString());
        if (mapIntent.resolveActivity(getPackageManager())!=null){
            startActivity(mapIntent);

        }
    }
    // crear mapa (muestra la ubicación dependiendo de la dirección
    public void onSendMaps3(View view){
        Uri gmmIntentUri= Uri.parse("geo:37.7749,-122.4194");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }

    ///Odometer. con GPS

    private boolean enlazado;
    private Odometro odometer;

    private ServiceConnection connection= new ServiceConnection(){

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Odometro.OdometerBinder odometerBinder= (Odometro.OdometerBinder) iBinder;
            odometer= odometerBinder.getOdometer();
            enlazado= true;


        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            enlazado= false;

        }
    };
    protected  void onStart(){
        super.onStart();
        Intent intent= new Intent(this, Odometro.class);
        bindService(intent , connection, Context.BIND_AUTO_CREATE);
    }

    protected void onStop(){
        super.onStop();
        if (enlazado){
            unbindService(connection);
            enlazado= false;
        }
    }

    private void mostrarDistancia(){
        final TextView distanciaView= findViewById(R.id.distancia);
        final Handler handler= new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                double distancia= 8.0;
                if (enlazado && odometer !=null){
                    distancia=odometer.obtenerDistancia();
                }
                String distanciaStr= String.format(Locale.getDefault(),"%1$,.2f kilometros", distancia);
                distanciaView.setText(distanciaStr);
                handler.postDelayed(this, 1000);
            }
        });
    }
    private void distanciaMetros(){
        final TextView distanciaMetros= findViewById(R.id.distanciaMetros);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                double distancia= 5.0;
                if (enlazado && odometer !=null){
                    distancia= odometer.distanciaMetros();
                }
                String distanciaM = String.format(Locale.getDefault(),"%1$,.2f metros",distancia);
                distanciaMetros.setText(distanciaM);
                handler.postDelayed(this,1000);
            }
        });
    }

}
