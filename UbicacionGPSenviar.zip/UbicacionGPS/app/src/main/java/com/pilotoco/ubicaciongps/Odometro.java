package com.pilotoco.ubicaciongps;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import java.util.Random;

public class Odometro extends Service {


    private final IBinder binder= new OdometerBinder();
    private final Random random= new Random();
    private static double distaciaEnMetros;
    private static double distaciaEnKilometros;
    private LocationListener Listener;
    private static Location ultimaLocalizacion;
    private static LocationManager locationManager;


    public class OdometerBinder extends Binder{ // Enlazar servicios
        Odometro getOdometer(){
            return Odometro.this;
        }
    }


    public Odometro() {
    }

    @Override
    public void onCreate(){
        super.onCreate();
        Listener = new LocationListener(){
            @Override
            public void onLocationChanged(@NonNull Location location){
                if (ultimaLocalizacion== null){
                    ultimaLocalizacion= location;
                }
                distaciaEnKilometros += location.distanceTo(ultimaLocalizacion);
                distaciaEnMetros = location.distanceTo(ultimaLocalizacion);
                ultimaLocalizacion = location;
            }
        };
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)!=
                        PackageManager.PERMISSION_GRANTED)
            {

            } else {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            String proveedor = locationManager.getBestProvider(new Criteria(), true);


            if (proveedor != null) {
                locationManager.requestLocationUpdates(proveedor, 2000, 1, Listener);

            }
        }

    }

    @Override
    public IBinder onBind(Intent intent) {

        return binder;
    }
    public double obtenerDistancia(){
        return this.distaciaEnKilometros;
    }
    public double distanciaMetros(){
        return this.distaciaEnMetros;
    }

    public void onDestroy(){
        super.onDestroy();
        if (locationManager!=null && Listener !=null){
            locationManager.removeUpdates(Listener);
        }
        locationManager=null;
        Listener=null;
    }
}